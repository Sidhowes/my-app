/*import React from 'react'
const Departments = () => {
  return (
    <div className="container">
    
      <h1 className="text-center" style={{paddingTop: "30%"}}>
        Departments
      </h1>
      
    </div>
  )
}
export default Departments;*/


import React,{Component} from 'react';

export class Departments extends Component{

    render(){
        return(
            <div className="mt-5 d-flex justify-content-left">
                This is Departments page.
            </div>
        )
    }
}